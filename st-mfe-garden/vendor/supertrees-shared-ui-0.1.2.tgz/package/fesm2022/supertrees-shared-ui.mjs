import * as i0 from "@angular/core";
import { Injectable, Pipe, signal } from "@angular/core";
import { HttpErrorResponse } from "@angular/common/http";
var RuntimeConfigService = class RuntimeConfigService {
	state = signal(null, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	config = this.state.asReadonly();
	async load(url = "config.json") {
		const res = await fetch(url, { cache: "no-store" });
		if (!res.ok) throw new Error(`โหลด ${url} ไม่ได้ (${res.status})`);
		this.state.set(await res.json());
	}
	set(config) {
		this.state.set(config);
	}
	apiUrl(path) {
		const c = this.state();
		if (!c) throw new Error("ยังไม่ได้โหลด runtime config");
		return `${c.apiBaseUrl.replace(/\/+$/, "")}${path.startsWith("/") ? path : `/${path}`}`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: RuntimeConfigService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: RuntimeConfigService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.7",
	ngImport: i0,
	type: RuntimeConfigService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
function apiErrorMessage(err, fallback = "เกิดข้อผิดพลาด ลองใหม่อีกครั้ง") {
	if (err instanceof HttpErrorResponse) {
		if (err.status === 0) return "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้";
		const body = err.error;
		if (body && typeof body.code === "string" && typeof body.message === "string") return body.message;
		if (err.status === 429) return "เรียกใช้งานถี่เกินไป รอสักครู่แล้วลองใหม่";
		if (err.status >= 502 && err.status <= 504) return "บริการยังไม่พร้อมใช้งาน ลองใหม่อีกครั้ง";
	}
	if (err instanceof Error && err.message) return err.message;
	return fallback;
}
function apiErrorCode(err) {
	if (err instanceof HttpErrorResponse) {
		const body = err.error;
		if (body && typeof body.code === "string") return body.code;
	}
	return null;
}
const SQM_PER_RAI = 1600;
const SQM_PER_NGAN = 400;
const SQM_PER_WA = 4;
function sqmToRaiNganWa(sqm) {
	const rai = Math.floor(sqm / SQM_PER_RAI);
	const rest = sqm - rai * SQM_PER_RAI;
	const ngan = Math.floor(rest / 400);
	return {
		rai,
		ngan,
		wa: Math.round((rest - ngan * 400) / 4 * 10) / 10
	};
}
function raiNganWaToSqm({ rai, ngan, wa }) {
	return rai * SQM_PER_RAI + ngan * 400 + wa * 4;
}
const formats = {
	date: { dateStyle: "medium" },
	datetime: {
		dateStyle: "medium",
		timeStyle: "short"
	},
	long: {
		dateStyle: "long",
		timeStyle: "short"
	}
};
const cache = /* @__PURE__ */ new Map();
function formatThaiDate(value, format = "datetime") {
	let f = cache.get(format);
	if (!f) {
		f = new Intl.DateTimeFormat("th-TH-u-ca-buddhist", {
			...formats[format],
			timeZone: "Asia/Bangkok"
		});
		cache.set(format, f);
	}
	return f.format(typeof value === "string" ? new Date(value) : value);
}
var StThaiDatePipe = class StThaiDatePipe {
	transform(value, format = "datetime") {
		return value ? formatThaiDate(value, format) : "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: StThaiDatePipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: StThaiDatePipe,
		isStandalone: true,
		name: "stThaiDate"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.7",
	ngImport: i0,
	type: StThaiDatePipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "stThaiDate" }]
	}]
});
var StRaiNganWaPipe = class StRaiNganWaPipe {
	transform(sqm) {
		if (sqm == null) return "";
		const { rai, ngan, wa } = sqmToRaiNganWa(sqm);
		return [
			rai && `${rai.toLocaleString("th-TH")} ไร่`,
			ngan && `${ngan} งาน`,
			(wa || !rai && !ngan) && `${wa} ตร.วา`
		].filter(Boolean).join(" ");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: StRaiNganWaPipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: StRaiNganWaPipe,
		isStandalone: true,
		name: "stRaiNganWa"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.7",
	ngImport: i0,
	type: StRaiNganWaPipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "stRaiNganWa" }]
	}]
});
var StDistancePipe = class StDistancePipe {
	transform(m, digits = 1) {
		if (m == null) return "";
		return m >= 1e3 ? `${(m / 1e3).toFixed(2)} กม.` : `${m.toFixed(digits)} ม.`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: StDistancePipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.7",
		ngImport: i0,
		type: StDistancePipe,
		isStandalone: true,
		name: "stDistance"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.7",
	ngImport: i0,
	type: StDistancePipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "stDistance" }]
	}]
});
export { RuntimeConfigService, SQM_PER_NGAN, SQM_PER_RAI, SQM_PER_WA, StDistancePipe, StRaiNganWaPipe, StThaiDatePipe, apiErrorCode, apiErrorMessage, formatThaiDate, raiNganWaToSqm, sqmToRaiNganWa };

//# sourceMappingURL=supertrees-shared-ui.mjs.map