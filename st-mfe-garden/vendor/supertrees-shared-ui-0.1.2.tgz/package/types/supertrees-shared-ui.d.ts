import * as i0 from "@angular/core";
import { PipeTransform } from "@angular/core";
export interface StRuntimeConfig {
  /** เช่น http://localhost:8000 (Kong) — ไม่มี / ท้าย */
  apiBaseUrl: string;
  /** MOCK-003: แปลงทดลองจนกว่าจะมีแปลงจริง (TASK-004) */
  demoParcelId?: string;
  /** แผนที่ (CONF-006) — แหล่ง tile อยู่ใน config เพื่อเปลี่ยนผู้ให้บริการได้โดยไม่ build ใหม่ */
  map?: StMapConfig;
}
export interface StRasterTileSource {
  /** URL แบบ {z}/{x}/{y} */
  url: string;
  attribution: string;
  maxZoom?: number;
}
export interface StMapConfig {
  /** ภาพดาวเทียม — ใช้ปักจุดอ้างอิง/ดูแปลง */
  satellite: StRasterTileSource;
  /** ชั้นชื่อสถานที่/ขอบเขตซ้อนบนภาพดาวเทียม (ไม่บังคับ) */
  labels?: StRasterTileSource;
  /** จุดเริ่มต้นของแผนที่ [lng, lat] + ซูม */
  initialCenter?: [number, number];
  initialZoom?: number;
}
export declare class RuntimeConfigService {
  private readonly state;
  readonly config: import("@angular/core").Signal<StRuntimeConfig | null>;
  /** เรียกครั้งเดียวจาก shell (provideAppInitializer) */
  load(url?: string): Promise<void>;
  set(config: StRuntimeConfig): void;
  /** apiUrl('/api/v1/gardens/...') */
  apiUrl(path: string): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<RuntimeConfigService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare function apiErrorMessage(err: unknown, fallback?: string): string;
export declare function apiErrorCode(err: unknown): string | null;
export declare const SQM_PER_RAI = 1600;
export declare const SQM_PER_NGAN = 400;
export declare const SQM_PER_WA = 4;
export interface RaiNganWa {
  rai: number;
  ngan: number;
  /** ตร.วา (ทศนิยม 1 ตำแหน่ง) */
  wa: number;
}
export declare function sqmToRaiNganWa(sqm: number): RaiNganWa;
export declare function raiNganWaToSqm({ rai, ngan, wa }: RaiNganWa): number;
declare const formats: {
  date: {
    dateStyle: "medium";
  };
  datetime: {
    dateStyle: "medium";
    timeStyle: "short";
  };
  long: {
    dateStyle: "long";
    timeStyle: "short";
  };
};
export declare function formatThaiDate(value: string | Date, format?: keyof typeof formats): string;
export declare class StThaiDatePipe implements PipeTransform {
  transform(value: string | Date | null | undefined, format?: keyof typeof formats): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<StThaiDatePipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<StThaiDatePipe, "stThaiDate", true>;
}
/** ตร.ม. → "2 ไร่ 1 งาน 30.5 ตร.วา" */
export declare class StRaiNganWaPipe implements PipeTransform {
  transform(sqm: number | null | undefined): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<StRaiNganWaPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<StRaiNganWaPipe, "stRaiNganWa", true>;
}
/** เมตร → "4.2 ม." / "1.35 กม." */
export declare class StDistancePipe implements PipeTransform {
  transform(m: number | null | undefined, digits?: number): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<StDistancePipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<StDistancePipe, "stDistance", true>;
}
export {};